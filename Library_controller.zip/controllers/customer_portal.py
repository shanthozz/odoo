import base64
from odoo import http
from odoo.http import request
import logging
from odoo.exceptions import UserError


class BorrowerMasterController(http.Controller):
    _logger = logging.getLogger(__name__)

    @http.route('/my/custom_menu', auth='user', website=True)
    def custom_menu_page(self, **kw):
        # Fetch all the Borrower Master records
        borrower_records = request.env['borrower.master'].search([])

        # Pass the records to the template
        return request.render('library_management.custom_menu_page', {
            'borrower_records': borrower_records,
        })

    @http.route(['/my/order/<model("borrower.master"):order>'], type='http', auth='user', website=True)
    def order_detail(self, order, **kw):
        return request.render('library_management.custom_order_detail_page', {
            'order': order
        })

    @http.route('/my/order/send_message', type='http', auth='user', methods=['POST'], website=True)
    def send_message(self, **kwargs):
        order_id = int(kwargs.get('order_id'))
        message_body = kwargs.get('message_body')
        attachment_file = request.httprequest.files.get(
            'attachment')  # Get the attachment file

        # Fetch the order record
        order = request.env["borrower.master"].browse(order_id)

        if order:
            # Create the message with the message body
            message = order.message_post(body=message_body)

            # Handle attachment if a file is uploaded
            if attachment_file:
                # Create an attachment record
                attachment = request.env['ir.attachment'].create({
                    'name': attachment_file.filename,
                    # Properly encode the file
                    'datas': base64.b64encode(attachment_file.read()),
                    'type': 'binary',
                    'res_model': 'borrower.master',  # Link the attachment to the order model
                    'res_id': order_id,
                })

                # Add the attachment to the message
                message.write({'attachment_ids': [(4, attachment.id)]})

        # Redirect back to the order detail page
        return request.redirect('/my/order/{}'.format(order_id))
