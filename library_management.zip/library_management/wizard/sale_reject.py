# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import api,fields, models, _
from odoo.exceptions import UserError, AccessError,ValidationError
from datetime import datetime


class SaleReject(models.TransientModel):
    
    _name = "sale.reject"
    _description = "Sale Reject"

    sale_id = fields.Many2one("sale.order",string="Sale ID")
    reason = fields.Char("Reason for Reject")
    reject_by = fields.Many2one("res.users",string="Reject By")
    reject_date = fields.Datetime("Rejection Date")
    status = fields.Char("Status",invisible=True)

    def action_update(self):

        # rec = self.env.context.get('active_ids')
        # x = self.env['sale.order'].browse(rec)
        self.sale_id.track_history_line.create({
                'track_history_id': self.sale_id.id, 
                'rejected_by': self.reject_by.id,
                'rejection_date': self.reject_date,
                'reason': self.reason,
                'status':"Rejected"
            })
        self.sale_id.state = 'rejected'
        



        # x = self.env['sale.order'].search([('name','=',self.sale_id.name)])
        # for history in x:
        #     history.track_history_line.create({
        #         'track_history_id': x.id, 
        #         'rejected_by': self.reject_by.id,
        #         'rejection_date': self.reject_date,
        #         'reason': self.reason
        #     })

        # history.state = 'rejected'
       
