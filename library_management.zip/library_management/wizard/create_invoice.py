# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import api,fields, models, _
from odoo.exceptions import UserError, AccessError,ValidationError


class CreateInvoice(models.TransientModel):
    
    _inherit = "sale.advance.payment.inv"
    
    
    def create_invoices(self):
        result = super(CreateInvoice,self).create_invoices()
        rec = self.env.context.get('active_id')
        sale = self.env['sale.order'].browse(rec)
        account = self.env['account.move'].search([('invoice_origin','=',sale.name)])
        account.write({"sale_order_id":sale.id})
        return result   
