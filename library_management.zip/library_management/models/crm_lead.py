# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import api,fields, models, _
from odoo.exceptions import UserError, AccessError,ValidationError

# ,order = id desc, limit=1

class CrmLead(models.Model):
    _inherit = 'crm.lead' 
    _description = "Crm Lead"

    crm_lead_id = fields.One2many('crm.lead.line','lead_id',string ="Crm Lead")


    
    # def action_sale_quotations_new(self):
        # result = super(CrmLead,self).action_sale_quotations_new()
        # rec = self.env['sale.order'].search([('opportunity_id','=',self.id)])
        # line_vals = []
        # for line in self.crm_lead_id:
        #     vals = (0,0,{
        #             'product_id':line.product_id.id,
        #             'product_uom_qty':line.product_qty,
        #             'price_unit':line.unit_price,
        #             'price_subtotal':line.sub_total,
        #             'order_id':rec.id,
        #              })
        #     line_vals.append(vals)
        # rec.write({'order_line':line_vals})
        # return result 
    def _prepare_opportunity_quotation_context(self):
        self.ensure_one()
        quotation_context = super(CrmLead, self)._prepare_opportunity_quotation_context() 
        line_vals = []
        for line in self.crm_lead_id:
            line_vals.append((0, 0, {
                'product_id': line.product_id.id,
                'product_uom_qty':line.product_qty,
                'price_unit':line.unit_price,
                'price_subtotal':line.sub_total,
            }))
        print("0000000000000000000...0",line_vals)
        if line_vals:
            quotation_context['default_order_line'] = line_vals
        return quotation_context
 



class CrmLeadLine(models.Model):
   
    _name = 'crm.lead.line'
    _description = "Crm Lead Line"

    product_id = fields.Many2one("product.product", string="Product")
    product_qty = fields.Float("Quantity")
    unit_price = fields.Float("Unit Price")
    sub_total = fields.Float("Total")    
    
    lead_id = fields.Many2one('crm.lead')

