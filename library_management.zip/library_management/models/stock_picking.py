# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import api,fields, models, _
from odoo.exceptions import UserError, AccessError,ValidationError



class StockPicking(models.Model):
    _inherit = "stock.picking" 

    sale_order_id = fields.Many2one('sale.order',string="Sale Order ID")

    
