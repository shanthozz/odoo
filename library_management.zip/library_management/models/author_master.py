# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import api,fields, models, _
from odoo.exceptions import UserError, AccessError

class AuthorMaster(models.Model):
    
    _name = "author.master"
    _description = "Author Master"

    name = fields.Char('Author Name', required=True, index=True, copy=False)
    biography = fields.Text("Biography")








