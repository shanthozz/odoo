# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import api,fields, models, _
from odoo.exceptions import UserError, AccessError

class BookMaster(models.Model):
    
    _name = "book.master"
    _description = "Book Master"

    name = fields.Char('Book Name', required=True, index=True, copy=False,help= "Enter the Book Name")
    book_id = fields.Char('Book ID' )
    author = fields.Char("Author", invisible=True)	
    book_author = fields.Many2many('author.master',string="Author")
    published_date = fields.Date("Date of Published")
    edition = fields.Char("Book Edition")
    is_available = fields.Boolean("is Available")
    price = fields.Float("Book Price")
    quantity = fields.Integer("Quantity")

    def action_update(self):
        ctx = {
                'default_book_ids':self.id
            }
        return {
            'type': 'ir.actions.act_window',
            'name': _('Update Quantity'),
            'res_model': 'update.book',
            'view_mode': 'form',
            'context': ctx,
            'target': 'new',
        }    

    _sql_constraints = [('unique_book_id', 'unique (book_id)', 'ID  already exists!')]

    



