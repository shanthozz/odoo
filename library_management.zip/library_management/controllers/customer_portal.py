from odoo.addons.portal.controllers.portal import CustomerPortal

class PortalAccount(CustomerPortal):
   def _prepare_home_portal_values(self, counters):
       values = super()._prepare_home_portal_values(counters)
       values['loan_count'] = 1
       return values