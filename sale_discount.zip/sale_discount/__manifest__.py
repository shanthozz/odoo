# -*- coding: utf-8 -*-	
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Sale Discount',
    'version': '17.0',
    'category': 'Sale Discount',
    'sequence': -100,	
    'summary': 'Sale order Discount',
    'description': "Crm Lead Mail",
    'depends': ['base','sale' ],
    'data': [
        'security/order_approve_group.xml',
        'security/ir.model.access.csv',
        'views/sale_order_view.xml',
        'views/sale_discount_view.xml',
    ],
    'licence' : 'LGPL-3',
    'installable': True,
    'auto_install': False,
    'application': True,
}
