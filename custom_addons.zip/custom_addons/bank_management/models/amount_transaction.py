from odoo import fields, models, _
from datetime import datetime
from odoo.exceptions import UserError,AccessError


class AmountTransaction(models.Model):
    
    _name = "amount.transaction"
    _description = "Amount Transaction"

    transaction_type = fields.Selection([
        ('deposit', "Deposit"),
        ('withdrawal', "Withdrawal"),
        ],      
        string="Transaction" ,index=True)
    state = fields.Selection([
        ('draft', "Draft"),
        ('success', "Transaction Completed"),
        ],      
        default='draft',string="Transaction" ,index=True )
    account_number = fields.Many2one("bank.customer",string="Account Number")
    amount = fields.Float(string="Amount")
    
    def action_confirm(self):
        acc_id = self.env['bank.customer'].search([('name','=',self.account_number.name)])
        if acc_id.freeze == True:
            raise AccessError(_("The Enter Account is Freezed!, Please Contact Branch Manager"))

        elif acc_id and self.transaction_type == 'deposit':
            acc_id.write({'balance': acc_id.balance + self.amount})
            acc_id.transaction_ids.create({
                'customer_id':acc_id.id,
                'amount':+self.amount,
                'description': f"by cash deposit, initiated by {self.env.user.name}",
                'date_time': datetime.now(),
                'status':self.transaction_type
                })
            self.state = 'success'
        elif acc_id and self.transaction_type == 'withdrawal':
            acc_id.write({'balance': acc_id.balance - self.amount})
            acc_id.transaction_ids.create({
                'customer_id':acc_id.id,
                'amount':- self.amount,
                'description': f"Amount Withdrawal, initiated by {self.env.user.name}",
                'date_time': datetime.now(),
                'status':self.transaction_type
                })
            self.state = 'success'
        else:
            raise UserError(_('Account not Found'))
