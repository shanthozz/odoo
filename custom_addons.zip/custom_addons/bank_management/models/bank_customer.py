from odoo import api,fields, models, _
from datetime import datetime
import re

class BankCustomer(models.Model):
    
    _name = "bank.customer"
    _description = "Bank Customer"
    _inherit = ["mail.thread", 'mail.activity.mixin']

    name = fields.Char("Account Number")
    customer_name = fields.Char(string="Customer Name")
    father_name = fields.Char(string="Father Name")
    dob = fields.Date(string="Date of Birth")
    gender = fields.Selection([
        ('male', "Male"),
        ('female', "Female"),
        ('trans', "Trans Gender"),
        ('other', "Others"),
        ],      
        string="Gender",index=True)
    nationality = fields.Char(string="Nationality")
    email = fields.Char(string="Email")
    phone = fields.Char(string="Phone")
    image = fields.Binary(string="Image", max_width=1920, max_height=1920)
    address = fields.Char(string="Address")
    city = fields.Char(string="City")
    state = fields.Many2one("res.country.state",string="State")
    postal_code = fields.Char(string="Postal Code")
    country = fields.Many2one("res.country",string="Country")
    ifsc = fields.Char(related="branch.ifsc",string="IFSC")
    branch = fields.Many2one("bank.master",string="Branch", ondelete='restrict')
    balance = fields.Float("Current Balance")
    transaction_ids = fields.One2many('account.transaction','customer_id',string="Transaction")
    documents = fields.Many2many("ir.attachment",string="Documents",attachment=True)
    attachment = fields.Binary(string="Attachment",filename="binary_file_name")
    binary_file_name = fields.Char("Binary File Name")
    account_type = fields.Selection([
        ('savings', "Savings"),
        ('current', "Current"),
        ('trade', "Trade Account"),
        ('demate', "Demat"),
        ('salary', "Salary"),
        ('fd', "Fixed Deposit"),
        ('rd', "Recurring Deposit"),
        ],      
        string="Account Type",index=True)
    freeze = fields.Boolean(string="Account Freeze")
    adhaar = fields.Char(string="Adhaar Number")
    pan = fields.Char(string="PAN Number")

    # @api.onchange('branch')
    # def get_ifsc(self):
    #     self.ifsc = self.branch.ifsc

    @api.constrains('phone')
    def _check_phone_number(self):
        for record in self:
            if record.phone:
                if not re.match(r'^\+?[0-9]{10,15}$', record.phone):
                    raise models.ValidationError("Please enter a valid phone number. It should contain only numbers and be between 10 and 15 digits long.")
                if re.match(r'(\d)\1{9,}$', record.phone):
                    raise models.ValidationError("Phone number cannot contain repeated digits.")

    def action_demo(self):
        print("**************************************************")
        ids = self.env.context.get('active_ids')
        print(ids,'-----------------------------------------------')


class AccountTransaction(models.Model):
    _name = "account.transaction"
    _description = "Account Transaction"

    date_time = fields.Datetime(string='Date')
    description = fields.Char(string="Description")
    status = fields.Char(string="Status")
    amount = fields.Float(string="Amount")
    customer_id =fields.Many2one("bank.customer")
    