from odoo import fields, models, _

class BankMaster(models.Model):
    
    _name = "bank.master"
    _description = "Bank Master"
    _rec_name = 'branch'


    name = fields.Char(string="Bank Name")
    branch = fields.Char(string="Branch",ondelete='restrict')
    address = fields.Char(string="Address")
    city = fields.Char(string="City")
    state = fields.Many2one("res.country.state",string="State")
    postal_code = fields.Char(string="Postal Code")
    country = fields.Many2one("res.country",string="Country")
    ifsc = fields.Char(string="IFSC")
    conditions = fields.Html(string="Terms and Condition")
    