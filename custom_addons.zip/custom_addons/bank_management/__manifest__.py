# -*- coding: utf-8 -*-	
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Bank',
    'version': '17.0',
    'category': 'Bank',
    'sequence': -100,	
    'summary': 'Bank',
    'description': "Bank Customers",
    'depends': ['base','mail'],
    'data': [
        'security/ir.model.access.csv',
        'views/bank_customer_views.xml',
        'views/bank_master_views.xml',
        'views/amount_transaction_views.xml',

    ],
    'licence' : 'LGPL-3',
    'installable': True,
    'auto_install': False,
    'application': True,
}
