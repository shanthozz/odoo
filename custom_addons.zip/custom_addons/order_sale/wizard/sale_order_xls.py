import base64
from io import BytesIO
import xlwt
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

class SaleOrderReport(models.TransientModel):
    
    _name = 'sale.order.report'


    from_date = fields.Date('From Date')
    to_date = fields.Date('To Date')

    @api.onchange('to_date')
    def _check_to_date(self):
        if self.from_date and self.to_date:
            if self.to_date < self.from_date:
                raise ValidationError("The 'To Date' cannot be earlier than the 'From Date'.")


    file_name = fields.Char('File Name')
    file_data = fields.Binary('File Data')

    def get_xls(self):
        workbook = xlwt.Workbook()
        worksheet = workbook.add_sheet('Sale Order Report')

        header_style = xlwt.easyxf('align: horiz center, vert center, wrap on; font: bold on; pattern:') #, fore_color light_blue;
        head_style = xlwt.easyxf('align: horiz left, vert center, wrap on; font: bold on; pattern:') #, fore_color light_blue;
        date_style = xlwt.easyxf('align: horiz center, vert center, wrap on;', num_format_str='YYYY-MM-DD')
        data_style = xlwt.easyxf('align: horiz center, vert center, wrap on;')

        worksheet.write_merge(0, 0, 0, 8, "Sale Order", header_style)

        worksheet.write_merge(1, 1, 0, 4, "From Date: {}".format(self.from_date), head_style)
        worksheet.write_merge(1, 1, 5, 8, "To Date: {}".format(self.to_date), head_style)

        worksheet.write(3, 0, "Serial No", header_style)
        worksheet.write(3, 1, "Sale Order Number", header_style)
        worksheet.write(3, 2, "Customer", header_style)
        worksheet.write(3, 3, "Order Date", header_style)
        worksheet.write(3, 4, "State", header_style)
        worksheet.write(3, 5, "Product", header_style)
        worksheet.write(3, 6, "Untaxed Amount", header_style)
        worksheet.write(3, 7, "Tax", header_style)
        worksheet.write(3, 8, "Total", header_style)
        

        sale_orders = self.env['sale.order'].search([
        ('date_order', '>=', self.from_date),
        ('date_order', '<=', self.to_date)
        ])

        row = 4
        for index, order in enumerate(sale_orders, start=1):

            worksheet.write(row, 0, index, data_style)
            worksheet.write(row, 1, order.name or '', data_style)
            worksheet.write(row, 2, order.partner_id.name or '', data_style)
            worksheet.write(row, 3, order.date_order or '', date_style)
            worksheet.write(row, 4, order.state or '', data_style)
            product_names = []
            for line in order.order_line:
                product_names.append(f"• {line.product_id.name}")
                product_content = "\n".join(product_names)
            worksheet.write(row, 5, product_content, data_style)
            worksheet.write(row, 6, order.amount_untaxed or 0.0, data_style)
            worksheet.write(row, 7, order.amount_tax or 0.0, data_style)
            worksheet.write(row, 8, order.amount_total or 0.0, data_style)
           
            product_line_count = len(product_names)
            row_height = 300
            row_height += product_line_count * 300

            worksheet.row(row).height_mismatch = True
            worksheet.row(row).height = row_height

            row += 1

        fp = BytesIO()
        workbook.save(fp)
        excel_file = base64.b64encode(fp.getvalue())
        fp.close()

        self.write({
        'file_name': 'Sale_Order_Report.xls',
        'file_data': excel_file,
        })

        mail_subject = 'Sale Order Report from {} to {}'.format(self.from_date, self.to_date)
        mail_body = 'Please find the attached Sale Order report for the specified date range.'

        # Define the email values
        mail_values = {
            'subject': mail_subject,    
            'body_html': mail_body,
            'email_to': 'recipient@example.com',  # Replace with the actual recipient's email address
            'attachment_ids': [(0, 0, {
                'name': 'Sale_Order_Report.xls',
                'type': 'binary',
                'datas': self.file_data,
            })],
        }

        # Send the email
        mail = self.env['mail.mail'].create(mail_values)
        mail.send()

        return {
        'type': 'ir.actions.act_url',
        'url': '/web/content/?model=' + self._name + '&id=' + str(self.id) +
        '&field=file_data&download=true&filename_field=file_name',
        'target': 'self',
        }