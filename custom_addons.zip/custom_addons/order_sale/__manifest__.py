# -*- coding: utf-8 -*-	
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Sale Order',
    'version': '17.0',
    'category': 'Sale Order',
    'sequence': -100,	
    'summary': 'Sale',
    'description': "Sale Order",
    'depends': ['base','sale'],
    'data': [
    
        'security/ir.model.access.csv',
        'views/order_sale_views.xml',
        'views/res_config_settings_views.xml',
        'wizard/sale_order_xls.xml',
        'data/sale_orders_data.xml',
    ],
    'licence' : 'LGPL-3',
    'installable': True,
    'auto_install': False,
    'application': True,
}
