from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError

class SaleOrder(models.Model):
    
    _inherit = "sale.order"

    name = fields.Char(string="Order Number", index='trigram', copy=False, default=lambda self:_('New'))
    reference = fields.Char("quotation reference")
    refer = fields.Char("Quotation Reference")

    @api.onchange('order_line')  # Trigger when order lines change
    def _onchange_order_line(self):
        """Check if the sale order has duplicate products when the order lines are modified."""
        if self.env['ir.config_parameter'].sudo().get_param('sale_line_valid') == 'validation':
            self._check_duplicate_products()


    def _check_duplicate_products(self):
        """Check if the sale order has duplicate products."""
        product_lines = {}
        for line in self.order_line:
            if line.product_id.id in product_lines:
                raise ValidationError("You cannot have duplicate products in the same sales order.")
            product_lines[line.product_id.id] = line

    def _add_product_qty(self):
        """Check for duplicate products in the sale order and merge quantities."""
        product_lines = {}
        for line in self.order_line:
            product_id = line.product_id.id
            if product_id in product_lines:
                # If product exists, update the existing product line with the new quantity
                existing_line = product_lines[product_id]
                existing_line.product_uom_qty += line.product_uom_qty
                # Remove the duplicate line
                line.unlink()
            else:
                product_lines[product_id] = line   # If product doesn't exist, store it in the dictionary


    @api.model
    def create(self, values):
        # # Call the super to retain default behavior
        # if values.name == _('New'):
        #     values.name = self.env['ir.sequence'].next_by_code('sale.order.quotation.sequence') or _('New')

        if 'name' not in values or values.get('name') == _('New'):
            name = self.env['ir.sequence'].next_by_code('sale.order.quotation.sequence') or _('New')
            values['name'] = name        
            values['reference'] = name

        order = super(SaleOrder, self).create(values)

        insufficient_stock_errors = []
        for line in order.order_line:
            if line.product_id:
                available_qty = line.product_id.qty_available
                if line.product_uom_qty > available_qty:
                    insufficient_stock_errors.append(
                _('You cannot order more than the available stock of %s! Only %s units are available.') % (line.product_id.name, available_qty)
            )                   
        if insufficient_stock_errors:
            raise UserError("\n".join(insufficient_stock_errors))

        config_settings = self.env['ir.config_parameter'].sudo().get_param('sale_line_valid')    # sale_order.sale_line_valid
        if  config_settings == 'sum_quantity':
            order._add_product_qty()            
        
        return order

    def write(self, values):        
        if 'order_line' in values:
            res = super(SaleOrder,self).write(values)
            self._add_product_qty()
            return res


    def action_confirm(self):       
        data = super(SaleOrder, self).action_confirm()
        if self.name:
                self.name = self.env['ir.sequence'].next_by_code('sale.order.number.sequence') or _('New')
        self.refer = self.reference
        return data

    # def action_whatsapp(self):
    #     whatsapp_url = 'https://api.whatsapp.com/send?phone=%s&text=%s' % (self.partner_id.phone,"Dear Coustomer")
    #     return {
    #     'type':'ir.actions.act_url',
    #     'target':'new',
    #     'url':'whatsapp_url'
    #     }


 

