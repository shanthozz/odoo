from odoo import api, fields, models, _
from odoo.exceptions import UserError, AccessError,ValidationError

class SaleOrder(models.TransientModel):
    
    _inherit = "res.config.settings"

    sale_line_valid = fields.Selection([
        ('validation', "Raise Validation"),
        ('sum_quantity', "Sum Quantity"),
        ],      
        index=True,readonly=False,config_parameter='sale_line_valid',string="Product Validation Policy :") #,config_parameter='sale_order.product_validation_policy'

    user_ids = fields.Many2many('res.users',string="User")


    # def set values (self):
    #     res = super(Hospital Settings, self).set_values()
    #     self.env['ir.config_parameter'].set_param('om_hospital.note', self.note)
    #     print("test", self.product_ids.ids)
    #     self.env['ir.config_parameter'].set_param('om_hospital.product_ids', self.product_ids.ids)
    #     return res
            