from . import sale_order
from . import res_config_settings
