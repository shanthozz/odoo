from odoo import  api, models, fields
from odoo.exceptions import ValidationError, UserError


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    state = fields.Selection(selection_add=[
        ('waiting_approval', 'Waiting for Approval')
    ], string='State', readonly=False)


    def action_confirm(self):
        if self.state != 'waiting_approval':
            discount_obj = self.env['sale.discount'].search([
                    ('from_value', '<=', self.amount_total),
                    ('to_value', '>=', self.amount_total)
                ], limit=1)
            for line in self.order_line:
                if discount_obj.discount < line.discount:
                    self.state = 'waiting_approval'
                    return False
        else:
            return super(SaleOrder,self).action_confirm()
        return super(SaleOrder,self).action_confirm()

    def _can_be_confirmed(self):
        self.ensure_one()
        return self.state in {'draft', 'sent', 'waiting_approval'}

    # discount_percentage = fields.Float(string="Discount Percentage")

    # @api.onchange('order_line')
    # def _discount_percentage(self):
    #     print("++++++++++++++++++++++++++++++++")
    #     for order in self:
    #         print(order,"++++++++++++++++++++")
    #         # Find the corresponding discount range
    #         discount_obj = self.env['sale.discount'].search([
    #             ('from_value', '<=', order.amount_total),
    #             ('to_value', '>=', order.amount_total)
    #         ], limit=1)  # Ensure only one discount is returned
    #         print(discount_obj,"++++++++++++++++++++++++++")
            
    #         if discount_obj:
    #             order.discount_percentage = discount_obj.discount
    #             print(order.discount_percentage,"++++++++++++++++++++++++++++++")
    #         else:
    #             order.discount_percentage = 1

    #         order._apply_discount()

    # def _apply_discount(self):
    #     for order in self:
    #         for line in order.order_line:
    #             line.discount = order.discount_percentage  # Set the discount on the line

class SaleDiscount(models.Model):
    _name = "sale.discount"
    _description = "Sale Order Discount"

    from_value = fields.Float(string="From Value")
    to_value = fields.Float(string="To Value")
    discount = fields.Float(string="Discount Percentage")

    @api.onchange('to_value')
    def _check_values(self):
        for record in self:
            if record.to_value < record.from_value:
                raise ValidationError("The 'To Value' cannot be less than the 'From Value'.")


    @api.constrains('from_value')
    def _check_duplicate_ranges(self):
        for record in self:
            existing_range = self.search([
                ('from_value', '<=', record.to_value),
            ], limit=1)
            if existing_range:
                raise ValidationError("A discount range with this range is already exists! please give the correct range. ")
