# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import api,fields, models, _
from odoo.exceptions import UserError, AccessError,ValidationError


class SaleProduct(models.TransientModel):
    
    _name = "sale.product"
    _description = "Sale Product"
 
    sale_order_id = fields.Many2one("sale.order")   
    sale_product_line = fields.One2many('sale.product.line','sale_product_id',string="Update Sale Product")

    def action_update(self):
        sale_product= self.env['sale.order']
        line_vals = []
        for line in self.sale_product_line:
            vals = (0,0, {
                    'product_id':1,
                    'name':line.product_name.name,
                    'product_uom_qty':line.product_qty,
                    'price_unit':line.product_price,
                    # 'product_uom':line.uom.id,
                    'order_id':self.sale_order_id.id
                    })
            line_vals.append(vals)
        self.sale_order_id.write({'order_line':line_vals})

    # @api

class SaleProductLine(models.TransientModel):

    _name = "sale.product.line"
    _description = "Sale Product Line"

    product_name = fields.Many2one("product.template")
    product_qty = fields.Integer("Quantity")
    product_price = fields.Float("Pice")
    uom = fields.Many2one("uom.uom")
    sale_product_id = fields.Many2one("sale.product")



