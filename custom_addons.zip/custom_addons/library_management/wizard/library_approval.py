# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import api,fields, models, _
from odoo.exceptions import UserError, AccessError,ValidationError


class LibraryApproval(models.TransientModel):
    
    _name = "library.approval"
    _description = "Library Approval"
    

    
    name = fields.Char('Book Name',index=True, copy=False)
    book_id = fields.Char('Book ID')  
    # book_author = fields.Many2many('author.master',string="Author")
    published_date = fields.Date("Date of Published")
    edition = fields.Char("Book Edition")
    is_available = fields.Boolean("is Available")
    price = fields.Float("Book Price")
    quantity = fields.Integer("Quantity")
    # books_id = fields.Many2one('borrower.master')
    

    def action_create_book(self):
        self.env['book.master'].create({
            'name':self.name,
            'book_id':self.book_id,
            'published_date':self.published_date, 
            'edition':self.edition,
            'price':self.price,
            'quantity':self.quantity

            })   


