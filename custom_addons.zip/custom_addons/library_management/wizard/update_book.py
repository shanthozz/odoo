# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import api,fields, models, _
from odoo.exceptions import UserError, AccessError,ValidationError


class UpdateBook(models.TransientModel):
    
    _name = "update.book"
    _description = "Update Book"

    book_name = fields.Char("Book Name", invisible=True)
    qty = fields.Integer("Quantity")
    book_ids = fields.Many2one("book.master")


    def action_approve(self):
        if self.book_ids:
            self.book_ids.quantity = self.qty        

       
