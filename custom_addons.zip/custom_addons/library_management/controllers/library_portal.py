import base64
from odoo import http
from odoo.http import request
import logging
from odoo.exceptions import UserError


class BorrowerMasterController(http.Controller):
    _logger = logging.getLogger(__name__)
   

    @http.route('/my/library_orders', auth='user', website=True)
    def custom_menu_page(self, **kw):
        # Check if the current user is a portal user
        user_groups = request.env.user.groups_id.mapped('name')
        self._logger.debug(f"User groups: {user_groups}")
        states_to_filter = ['draft', 'checkin', 'checkout']

        borrower_records = request.env['borrower.master'].search([('state', 'in', states_to_filter)])
        borrower_count = len(borrower_records)
        # Pass the records to the template
        return request.render('library_management.custom_menu_page', {
            'borrower_records': borrower_records,
            'borrower_count': borrower_count,
        })


    @http.route(['/my/library_orders/<model("borrower.master"):order>'], type='http', auth='user', website=True)
    def order_detail(self, order, **kw):
        return request.render('library_management.custom_order_detail_page', {
            'order': order
        })

    @http.route('/my/library_orders/send_message', type='http', auth='user', methods=['POST'], website=True)
    def send_message(self, **kwargs):
        order_id = int(kwargs.get('order_id'))
        message_body = kwargs.get('message_body')
        attachment_files = request.httprequest.files.getlist('attachment')  # Get the list of uploaded files

        # Fetch the order record
        order = request.env["borrower.master"].browse(order_id)

        if order:
            # Create the message with the message body (text content), ensuring it's not treated as an attachment
            message = order.message_post(body=message_body)

            # Handle attachments if any files are uploaded
            if attachment_files:
                attachment_ids = []  # List to store the attachment ids
                for attachment_file in attachment_files:
                    # Create an attachment record for each uploaded file
                    attachment = request.env['ir.attachment'].create({
                        'name': attachment_file.filename,
                        'datas': base64.b64encode(attachment_file.read()),
                        'type': 'binary',
                        'res_model': 'borrower.master',  # Link the attachment to the order model
                        'res_id': order_id,
                    })
                    attachment_ids.append(attachment.id)  # Add the attachment id to the list

                # Add the attachments to the message (keeping message body as text)
                if attachment_ids:
                    message.write({'attachment_ids': [(4, aid) for aid in attachment_ids]})

            # Optional: Confirm the order action after sending the message
            # order.action_confirm()

            # Add a success message to the redirect
            success_message = "Your message has been sent successfully!"

        # Redirect back to the order detail page with success message
        return request.redirect('/my/library_orders/{}'.format(order_id) + "?success=" + success_message)


    @http.route('/my/library_orders/update_unit_price', type='http', auth='user', methods=['POST'], website=True)
    def update_unit_price(self, **kwargs):
        # Retrieve order_id and line_data
        order_id = int(kwargs.get('order_id'))
        line_data = kwargs.get('line_data', {})  # This should be a dictionary

        # Debugging: print out received line data
        print(line_data, "+++++++++++++++")
        
        # Fetch the order using the order_id
        order = request.env["borrower.master"].browse(order_id)
        
        # Debugging: check if order exists
        print(order, "+++++++++++++++")
        
        # If order doesn't exist, redirect to the same page
        if not order.exists():
            return request.redirect('/my/library_orders/{}'.format(order_id))
        
        # If no line data, return to the order page
        if not line_data:
            return request.redirect('/my/library_orders/{}'.format(order_id))
        
        # Iterate over lines in the order
        for line in order.borrower_master_line:
            # Extract the unit price from line_data using line_id
            line_unit_price = line_data.get(str(line.id), {}).get('unit_price')

            if line_unit_price:
                try:
                    line_unit_price = float(line_unit_price)
                    line.write({
                        'unit_price': line_unit_price  # Update the unit_price
                    })
                except ValueError:
                    print(f"Invalid unit price for line {line.id}: {line_unit_price}")
        
        # Redirect back to the order page with a success message
        return request.redirect('/my/library_orders/{}'.format(order_id))








