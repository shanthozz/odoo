# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import api,fields, models, _
from odoo.exceptions import UserError, AccessError,ValidationError
from datetime import datetime



class SaleOrder(models.Model):
    _inherit = "sale.order" 


    sale_date = fields.Date(string="Sale Date")
    track_history_line = fields.One2many('track.history','track_history_id',string="History Track")
    
    state = fields.Selection(selection_add=[
        ('waiting_approval', 'Waiting for Approval'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ], string='State', readonly=False)


    def action_set_waiting_approval(self):
        self.state = 'waiting_approval'

    def action_set_approved(self):
        self.track_history_line.create({
            'track_history_id':self.id,
            'rejected_by':self.env.user.id, 
            'rejection_date':datetime.now(),
            'status':"Approved" 
            })
        self.state = 'approved'
        return {
            'effect':{
            'fadeout':'slow',
            'message':'Sale Order Approved',
            'type':'rainbow_man',
            }
    }

    def action_set_rejected(self):
        return {
            'type': 'ir.actions.act_window',
            'name': _('Rejection'),
            'res_model': 'sale.reject',
            'view_mode': 'form',
            'context': {
                'default_sale_id':self.id,
                'default_reject_date':datetime.now(),
                'default_reject_by':self.env.user.id
                },
            'target': 'new',

        }
    def action_confirm(self):
        result = super(SaleOrder,self).action_confirm()
        self.sale_date = fields.Date.today()

        for order in self:
            pickings = self.env['stock.picking'].search([('origin', '=', order.name)])
            pickings.write({'sale_order_id': order.id})                                 
        return result

    def action_add_product(self):
        ctx = {
                'default_sale_order_id':self.id
            }
        return {
            'type': 'ir.actions.act_window',
            'name': _('Add Product'),
            'res_model': 'sale.product',
            'view_mode': 'form',
            'context': ctx,
            'target': 'new',

        }
    
class SaleOrderLine(models.Model):
    _inherit = "sale.order.line"

    product_code = fields.Char(string="Product Code")

class TrackHistory(models.Model):
    _name = 'track.history'
    _description = 'Track History'

    reason =  fields.Char("Reason",required=True)
    rejected_by =  fields.Many2one('res.users',string="User")
    rejection_date = fields.Datetime('Date of Rejection')
    status = fields.Char("Status")
    track_history_id = fields.Many2one('sale.order')




    
