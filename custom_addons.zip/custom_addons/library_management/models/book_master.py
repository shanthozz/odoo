# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import api,fields, models, _
from odoo.exceptions import ValidationError,UserError, AccessError

""" 
1. api unused 
2. exceptions unused
"""

class BookMaster(models.Model):
    
    _name = "book.master"
    _description = "Book Master"

    name = fields.Char('Book Name', required=True, index=True, copy=False,help= "Enter the Book Name")
    book_id = fields.Char('Book ID' )
    author = fields.Char("Author", invisible=True)	# Needless to use invisible
    book_author = fields.Many2many('author.master',string="Author")
    published_date = fields.Date("Date of Published")
    edition = fields.Char("Book Edition")
    is_available = fields.Boolean("is Available")
    price = fields.Float("Book Price")
    quantity = fields.Integer("Quantity")

    def action_update(self):
        ctx = {
                'default_book_ids':self.id # ID is single why you have added _ids
            }
        return {
            'type': 'ir.actions.act_window',
            'name': _('Update Quantity'),
            'res_model': 'update.book',
            'view_mode': 'form',
            'context': ctx,
            'target': 'new',
        }    

    _sql_constraints = [('unique_book_id', 'unique (book_id)', 'ID  already exists!')]
    # _sql_constraints = [('quantity_postitve', 'CHECK (quantity >= 0)', 'Quantity Cannot Be Negative')]

    @api.constrains('quantity')
    def negative_qty(self):
        if self.quantity<0:
            raise ValidationError("negative qty")

