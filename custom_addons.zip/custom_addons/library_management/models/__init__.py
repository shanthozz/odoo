from . import book_master
from . import author_master
from . import borrower_master
from . import sale_order
from . import crm_lead
from . import stock_picking
from . import account_move
from . import book_picking
from . import res_company

