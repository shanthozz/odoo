# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import api,fields, models, _
from odoo.exceptions import UserError, AccessError,ValidationError


class BookPicking(models.Model):
    
    _name = "book.picking"
    _description = "Book Picking"

    name = fields.Many2one('res.partner', index=True, copy=False)
    address = fields.Text("Address")
    check_out = fields.Date("Check out")
    check_in= fields.Date("Check in")
    phone_no = fields.Char('Number')   
    total = fields.Float(string="Total" ,compute='_total_price', store=True)
    discount = fields.Float("Discount")
    order_no = fields.Char(string="Order", index='trigram', copy=False, default=lambda self:_('New'))
    book_order_id = fields.Many2one('borrower.master',string="Source Document")
    state = fields.Selection([
        ('checkout', "Check out"),
        ('checkin', "Check in"),
        ],
        string="Status",
        readonly=False, copy=False, index=True,
        default='checkout')

    book_picking_line = fields.One2many('book.picking.line','book_line_id', string="book_picking_line")

    @api.model
    def create(self,vals):
        if vals.get('order_no','New') == 'test':
            vals['order_no'] = self.env['ir.sequence'].next_by_code('book.picking.sequence') or 'New'
        result = super(BookPicking,self).create(vals)
        return result
            
    def action_checkin(self):
        self.state = 'checkin'
        self.book_order_id.state = 'checkin'
        self.book_order_id.check_in = self.check_in
        

 
class BookMasterLine(models.Model):
    _name = "book.picking.line"
    _description = "Book Picking Line"


    book_name_id = fields.Many2one('book.master',string="Name", required=True ) # domain=[('quantity','>',45)]
    book_id = fields.Char(string="Book ID")
    book_price =fields.Float("Price")
    book_line_id = fields.Many2one('book.picking')
    qty = fields.Integer("Qty",default= 1)
    unit_price = fields.Float("Unit Price",digits="Discount")
    
    








