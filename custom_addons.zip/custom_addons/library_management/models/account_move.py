# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import api,fields, models, _
from odoo.exceptions import UserError, AccessError,ValidationError

""" 
1. api unused 
2. exceptions unused
"""

class Accountmove(models.Model):
    _inherit = "account.move" 

    
    sale_order_id = fields.Many2one('sale.order',string="Sale Order ID")

    
