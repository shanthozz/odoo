# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import api,fields, models, _
import xlwt
import base64   
from io import BytesIO
from odoo.exceptions import UserError, AccessError,ValidationError


class BorrowerMaster(models.Model):
    
    _name = "borrower.master"
    _inherit = ["mail.thread", 'mail.activity.mixin']
    _description = "Borrower Master"
    _rec_name = 'order_no'

    name = fields.Many2one('res.partner', required=True, index=True, copy=False,tracking=True)
    # phone = fields.Char("Phone Number")
    address = fields.Text("Address")
    check_out = fields.Date("Check out")
    check_in= fields.Date("Check in")
    phone_no = fields.Char('Number')
    return_date = fields.Date("return Date" )
    comments = fields.Char(string="Comments")
    total = fields.Float(string="Total" ,compute='_total_price', store=True)
    discount = fields.Float("Discount")
    order_no = fields.Char(string="Order", index='trigram', copy=False, default=lambda self:_('New'))
    medium = fields.Many2one('utm.medium',string="Medium")
    delivery_count= fields.Integer(string="count")
    state = fields.Selection([
        ('draft', "Draft"),
        ('checkout', "Check out"),
        ('checkin', "Check in"),
        ('confirm', "Confirm"),
        ],  
        string="Status",
        readonly=False, copy=False, index=True,
        default='draft')
    # Add a Binary field to store the generated Excel file
    summary_file = fields.Binary(string="Summary File")
    file_name = fields.Char(string="File Name")

    def action_add_book(self):

        # ctx = {
        #         'default_books_id':self.id
        #     }
        return {
            'type': 'ir.actions.act_window',
            'name': _('Add New Book'),
            'res_model': 'library.approval',
            'view_mode': 'form',
            # 'context': ctx,
            'target': 'new',    

        }

    def action_confirm(self):
        self.state = 'confirm'
       
    def action_stage_sent(self):
        order = self.env['book.picking'].search([('book_order_id','=',self.id)])
        if not order:
            line_vals = []
            for lines in self.borrower_master_line:
                vals = (0,0, {
                    'book_name_id':lines.borrower_name_id.id,

                    'book_id':lines.book_id,
                    'unit_price':lines.unit_price,
                    'qty':lines.qty,
                    'book_price':lines.book_price
                    })
                line_vals.append(vals)
            # Create :  create with no id reference
            # Create with ID : only write no create    
            order = self.env['book.picking'].create({
                'book_order_id':self.id,
                'name':self.name.id,
                # 'order_no':self.order_no,
                'address':self.address, 
                'check_out':self.check_out,
                'phone_no':self.phone_no,
                'discount':self.discount,
                'total':self.total,
                'book_picking_line':line_vals
                })
            self.delivery_count += 1
            self.state = 'checkout'
            

    def action_stage_confirm(self):
        self.state = 'checkin'

    @api.model
    def create(self,vals):
        if vals.get('order_no','New') == 'New':
            vals['order_no'] = self.env['ir.sequence'].next_by_code('borrower.master.sequence') or 'New'
        result = super(BorrowerMaster,self).create(vals)
        return result

    # without condition    
    # @api.model
    #     def create(self, vals):
    #     vals['ref'] = self.env['ir.sequence'].next_by_code('hospital. patient')
    #     return super(Hospital Patient, self).create(vals)
        
        

    @api.onchange('name')
    def _onchange_get_phone(self):
        for rec in self:
            rec.phone_no= rec.name.phone
            rec.address= rec.name.street


    @api.constrains('borrower_master_line','discount','check_out')
    def action_validate_lines(self):
        if not self.borrower_master_line:
            raise ValidationError(_("Kindly Choose the Books."))
        elif self.discount < 0 :
            raise ValidationError(_("Discount Should not be negative."))
        elif self.total < 0 :
            raise ValidationError(_("Discount Should not be greater then the total value."))
        elif self.check_out != fields.Date.today():
            raise ValidationError(_("You Choosed wrong Checkout Date"))

    @api.depends('borrower_master_line.book_price')
    def _total_price(self):
        # tot=0
        # for rec in self.borrower_master_line :
        #     tot += rec.book_price
        # self.total=tot 
        for rec in self:
            x= sum(rec.borrower_master_line.mapped('book_price'))
            rec.total = x - rec.discount

    def action_view_delivery(self):
        order = self.env['book.picking'].search([('book_order_id', '=', self.id)],limit=1)
        if order:
            return {    
                'type': 'ir.actions.act_window',
                'res_id': order.id,
                'res_model': 'book.picking',
                'view_mode': 'tree,form',   
                'target': 'current',
                'domain': [('book_order_id', '=', self.id)],
            }
        


    def action_xlsx_report(self):
        # Create a new workbook and add a worksheet
        workbook = xlwt.Workbook()
        worksheet = workbook.add_sheet('Customer Report')
        # Define cell styles
        header_style = xlwt.easyxf('align: horiz center, vert center, wrap on; font: bold on;')
        data_style = xlwt.easyxf('align: horiz center, vert center, wrap on;')
        date_style = xlwt.easyxf('align: horiz center;')
        date_style.num_format_str = 'YYYY-MM-DD'
        data = self.env['borrower.master'].search([])  # Example: Fetch all hotel.manage records 
        for data in self.name:
            for data in self:
                print("11111",data)
                
        # Write data rows

        row = 3
        worksheet.write(0, 0, "Order Number", header_style)  # Sl.No
        worksheet.write(0, 1, 'Name', header_style)  # Date
        worksheet.write(0, 2, 'Phone Number', header_style)  # Customer Name
        worksheet.write(0, 3, 'Address', header_style)  # Address Name
        worksheet.write(0, 4, 'Check Out', header_style)  # Gender
        worksheet.write(0, 5, 'Check In', header_style)  # Gender
        worksheet.write(0, 6, 'Book', header_style)  # Gender
        worksheet.write(0, 7, 'Book ID', header_style)  # Genders
        worksheet.write(0, 8, 'Unit Price', header_style)  # Genders
        worksheet.write(0, 9, 'Quantity', header_style)  # Genders
        worksheet.write(0, 10, 'Price', header_style)  # Genders
        worksheet.write(5, 9, 'Total', header_style)  # Genders

        row = 1
        for record in data:
            worksheet.write(row, 0, record.order_no, data_style)  # Sl.No
            worksheet.write(row, 1, record.name.name or '', data_style)  # Date
            worksheet.write(row, 2, record.phone_no or '', data_style)  # Customer Name
            worksheet.write(row, 3, record.address or '', data_style)  # Address Name
            worksheet.write(row, 4, record.check_out or '', date_style)  # Gender
            worksheet.write(row, 5, record.check_in or '', date_style)  # Gender
            worksheet.write(5, 10, record.total or '', data_style)  # Gender
            row += 1
        row = 1
        for rec in self.borrower_master_line:
            worksheet.write(row,6, rec.borrower_name_id.name,data_style)
            worksheet.write(row,7, rec.book_id,data_style)
            worksheet.write(row,8, rec.unit_price,data_style)
            worksheet.write(row,9, rec.qty,data_style)
            worksheet.write(row,10, rec.book_price,data_style)
            row += 1

        # Save workbook to a BytesIO buffer
        fp = BytesIO()
        workbook.save(fp)
        excel_file = base64.b64encode(fp.getvalue())
        fp.close() 

        # Create and attach the file to the record
        attachment_data = {
            'summary_file': excel_file,
            'file_name': 'Customer_Report.xls',
        }
        self.write(attachment_data)
        # Return the action to open the wizard record with the attached file
        return {
            'type': 'ir.actions.act_url',
            'url': '/web/content/?model=' + self._name + '&id=' + str(self.id) +
                   '&field=summary_file&download=true&filename_field=file_name',
            'target': 'self',
        }
    borrower_master_line = fields.One2many('borrower.master.line','borrow_id', string="borrower_master_line")

class BookMasterLine(models.Model):
    _name = "borrower.master.line"
    _description = "Borrower Master Line"


    borrower_name_id = fields.Many2one('book.master',string="Name", required=True ) # domain=[('quantity','>',45)]
    book_id = fields.Char(string="Book ID")
    book_price =fields.Float("Price",compute= "action_update_price")
    borrow_id = fields.Many2one('borrower.master', string="Borrower")
    qty = fields.Integer("Qty",default= 1)
    unit_price = fields.Float("Unit Price",digits="Discount")
    
    @api.onchange('borrower_name_id')
    def _onchange_get_code(self):
        for rec in self:
            rec.book_id= rec.borrower_name_id.book_id
            rec.unit_price= rec.borrower_name_id.price

    @api.depends('unit_price','qty')
    def action_update_price(self):
        for rec in self:
            rec.book_price = rec.unit_price * rec.qty

    @api.constrains('qty')
    def _check_quantity_non_negative(self):
        for record in self:
            if record.qty < 0 :
                raise ValidationError("Quantity must be higher.!")


    








