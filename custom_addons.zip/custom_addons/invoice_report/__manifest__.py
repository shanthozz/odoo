# -*- coding: utf-8 -*-	
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Invoicing Report',
    'version': '17.0',
    'category': 'Invoicing Report',
    'sequence': -100,	
    'summary': 'Invoicing',
    'description': "Invoicing Report",
    'depends': ['base','account'],
    'data': [
    
        'views/invoice_report_views.xml',
    ],
    'licence' : 'LGPL-3',
    'installable': True,
    'auto_install': False,
    'application': True,
}
