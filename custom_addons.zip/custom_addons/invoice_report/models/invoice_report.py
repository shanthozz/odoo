from odoo import fields, models, _
import xlwt
import base64   
import json   
from io import BytesIO

class AccountMoveLine(models.Model):
    
    _inherit = "account.move.line"

    summary_file = fields.Binary(string="Summary File")
    file_name = fields.Char(string="File Name")
    
    def action_xls_report(self):
           
        # Create a new workbook and add a worksheet
        workbook = xlwt.Workbook()
        worksheet = workbook.add_sheet('Invoice xls Report')

        # Define cell styles
        header_style = xlwt.easyxf('align: horiz center, vert center, wrap on; font: bold on;')
        data_style = xlwt.easyxf('align: horiz center, vert center, wrap on;')
        date_style = xlwt.easyxf('align: horiz center;')
        date_style.num_format_str = 'YYYY-MM-DD'

        # # Fetch all the account move line records
        selected_ids = self.env.context.get('active_ids')
        data = self.env['account.move.line'].browse(selected_ids)
        print(data,"++++++++++++++")

        # Write headers
        worksheet.write(0, 0, "Date", header_style)
        worksheet.write(0, 1, 'Journal Entry', header_style)
        worksheet.write(0, 2, 'Account', header_style)
        worksheet.write(0, 3, 'Debit', header_style)
        worksheet.write(0, 4, 'Credit', header_style)
        worksheet.write(0, 5, 'Partner', header_style)
        worksheet.write(0, 6, 'Label', header_style)
        worksheet.write(0, 7, 'Analytic Distribution', header_style)

        # # Write data for each account move line record starting from row 1
        row = 1
        for rec in data:
            
            if rec.analytic_distribution:
                analytic_names = []
                tag_names = []
                for key, value in rec.analytic_distribution.items():
                # print(key, value)
                    analytic_id, tag_id = map(int, key.split(','))
                    print(analytic_id)
                    print(tag_id)
                    analytic_account = self.env['account.analytic.account'].browse(analytic_id)
                    analytic_name = analytic_account.name
                    analytic_partner_name = analytic_account.partner_id.name if analytic_account.partner_id else ''
                    combined_analytic = f"{analytic_name} - {analytic_partner_name}" if analytic_partner_name else analytic_name
                    tag_name = self.env['account.analytic.account'].browse(tag_id).name
                    analytic_names.append(combined_analytic)
                    tag_names.append(tag_name)
                    print(" | ".join(analytic_names))
                    print(" | ".join(tag_names))
                    res = f'({" | ".join(analytic_names)}),({" | ".join(tag_names)})'
                    print(res)

            worksheet.write(row, 0, rec.date, date_style)
            worksheet.write(row, 1, rec.move_name or '', data_style)
            worksheet.write(row, 2, rec.account_id.name or '', data_style)
            worksheet.write(row, 3, rec.debit or '0.0', data_style)
            worksheet.write(row, 4, rec.credit or '0.0', data_style)
            worksheet.write(row, 5, rec.partner_id.name or '', data_style)
            worksheet.write(row, 6, rec.name or '', data_style)           
            worksheet.write(row, 7, res or '', data_style)
            row += 1

        # # Save workbook to a BytesIO buffer
        fp = BytesIO()
        workbook.save(fp)
        excel_file = base64.b64encode(fp.getvalue())
        fp.close()

        # Create and attach the file to the record
        attachment_data = {
            'summary_file': excel_file,
            'file_name': 'Invoice_Report.xls',
        }
        self.write(attachment_data)

        # Return the action to open the wizard record with the attached file
        return {
            'type': 'ir.actions.act_url',
            'url': '/web/content/?model=' + rec._name + '&id=' + str(rec.id) +
                   '&field=summary_file&download=true&filename_field=file_name',
            'target': 'self',
        }