# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import fields, models, _
from odoo.exceptions import UserError, AccessError

class VehicleManagement(models.Model):
    
    _name = "vehicle.management"
    _description = "Vehicle Management"


    name = fields.Char('Customer Name', required=True, index=True, copy=False)
    address = fields.Text('Address', required=True, index=True, copy=False )	
    p_number = fields.Char('Phone Number')
    v_number = fields.Char(string="Vehicle Number")
    defect = fields.Text('Defect', required=True, index=True, copy=False)
    servicedby = fields.Char('Serviced By', required=True, index=True, copy=False) 
    s_parts = fields.Text('Spare Parts')
    date = fields.Date('Date', required=True, index=True, copy=False)
    s_date = fields.Date('Service Finished Date')
    n_date = fields.Date("Next Service Date")
    state = fields.Selection([
        ('draft', "Draft"),
        ('wait', "Waiting"),
        ('process', "Under Service"),
        ('done', "Done"),
        ],
        string="Status",
        readonly=True, copy=False, index=True,
        default='draft')
    vehicle_number_Lines = fields.One2many('vehicle.number.line','vehicle_id',string="Vehicle Number Line")

    def stage_draft(self):       
        self.state = 'draft'
    def stage_wait(self):
        self.state = 'wait'
    def stage_process(self):
        self.state = 'process'
    def stage_done(self):
        self.state = 'done'
  
class VehicleNumberLine(models.Model):
    _name = "vehicle.number.line"
    _description = "Vehicle Number Line"
    
    name = fields.Many2one('vehicle.management',string="Name",required=True)
    
    quantity = fields.Integer(string="Qty")
    u_price = fields.Integer('Unit Price')
    total = fields.Integer('Total')
    tax = fields.Many2many('res.users',string='Tax', index=True, copy=False, invisible=True)
    vehicle_id = fields.Many2one('vehicle.management')

