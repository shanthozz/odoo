# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import fields, models, _
from odoo.exceptions import UserError, AccessError

class VehicleNumber(models.Model):
    
    _name = "vehicle.number"
    _description = "Vehicle Number"


    c_number = fields.Many2many('res.users','vehicle_number_relation','vehicle_number_id','c_number',string='Chassis Number', required=True, index=True, copy=False,store=True)
    e_number = fields.Many2one('res.partner',string='Engine Number', required=True, index=True, copy=False)

    