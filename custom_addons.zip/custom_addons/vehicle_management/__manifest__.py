# -*- coding: utf-8 -*-	
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Vehicle Management',
    'version': '17.0',
    'category': 'Vehicle',
    'sequence': -100,	
    'summary': 'Vehicle',
    'description': "Vehicle Management",
    "author": "PPTS [India] Pvt.Ltd.",
    "website": "http://www.pptssolutions.com",
    'depends': ['base'],
    'data': [
        'security/ir.model.access.csv',
        'views/vehicle_management_views.xml',
	    'views/vehicle_number.xml',
            ],
    
    
    'installable': True,
    'auto_install': False,
    'application': True,
}
