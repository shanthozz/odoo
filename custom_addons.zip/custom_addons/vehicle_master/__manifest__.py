# -*- coding: utf-8 -*-	
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Vehicle',
    'version': '17.0',
    'category': 'Vehicle',
    'sequence': -100,	
    'summary': 'Vehicle',
    'description': "Vehicle Master",
    "author": "PPTS [India] Pvt.Ltd.",
    "website": "http://www.pptssolutions.com",
    'depends': ['base'],
    'data': [
        'security/ir.model.access.csv',
        'views/vehicle_master_views.xml',
        'views/customer_master_views.xml',

    ],
    
    
    'installable': True,
    'auto_install': False,
    'application': True,
}
