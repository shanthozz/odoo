# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import fields, models, _
from odoo.exceptions import UserError, AccessError

class VehicleMaster(models.Model):
    
    _name = "vehicle.master"
    _description = "Vehicle Master"


    name = fields.Char('Name', required=True, index=True, copy=False)
    code = fields.Integer('Code')	
    brand = fields.Char('Brand')
    fuel = fields.Selection([('petrol','Petrol'),('diesel','Diesel'),('electric','Electric (EV)')],string="Fuel Type")
    capacity = fields.Char('Seating Capacity')
    air_bags = fields.Selection([('a','1'),('b','2'),('c','3'),('d','4'),('e','5'),('f','6'),('g','7'),('h','8'),('i','9'),('j','10')],string='No of Air Bags') 
    color = fields.Char('Color')
    document = fields.Binary('Image')
    price = fields.Float('Price')
    html = fields.Html("Extra Information")
    email = fields.Many2one('customer.master')
    state = fields.Selection([
        ('draft', "Draft"),
        ('sent', "Sent"),
        ('confirm', "Confirm"),
        ('cancel', "Cancelled"),
        ],
        string="Status",
        readonly=True, copy=False, index=True,
        default='draft')

    vehicle_master_Lines = fields.One2many('vehicle.master.line','vehicle_id',string="Vehicle Master Line")

    partner_id = fields.Many2one('customer.master', string="Customer")
    user_ids = fields.Many2one('customer.master',string="Users")


    def action_stage_draft(self):       
        self.state = 'draft'
    def action_stage_sent(self):
        self.state = 'sent'
    def action_stage_confirm(self):
        self.state = 'confirm'
    def action_stage_cancel(self):
        self.state = 'cancel'

class VehicleMasterLine(models.Model):
    _name = "vehicle.master.line"
    _description = "Vehicle Master Line"

    name = fields.Char(string="Name")
    product_id = fields.Many2one('product.product', string="Product")
    partner_id = fields.Many2one('res.partner', string="Customer")
    
    quantity = fields.Integer(string="Qty")
    vehicle_id = fields.Many2one('vehicle.master')





