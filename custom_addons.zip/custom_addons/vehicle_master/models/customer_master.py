# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import api, fields, models, _
from odoo.exceptions import UserError, AccessError

class CustomerMaster(models.Model):
    
    _name = "customer.master"
    _description = "Customer Master"
    # _rec_name = 'email'


    name = fields.Char('Name', required=True, index=True, copy=False)
    age = fields.Integer('Age')
    address = fields.Text('Address')
    email = fields.Char('Email')
    dob = fields.Date('DOB')
    mo_contact = fields.Boolean('Mobile Contact')
    ma_contact =  fields.Boolean('Mail Contact')





