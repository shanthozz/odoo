# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import api,fields, models, _
from odoo.exceptions import UserError, AccessError

class CollegeMaster(models.Model):
    
    _name = "college.master"
    _description = "College Master"

    name = fields.Char('Student Name', required=True, index=True, copy=False)
    roll_number = fields.Char('Roll Number')	
    department = fields.Char('Department')
    section = fields.Char(string="Class")
    dateofbirth = fields.Date("Date of Birth") 
    college_id = fields.Many2one('student.master',string="Record ID")
    state = fields.Selection([
        ('draft', "Draft"),
        ('sent', "Sent"),
        ('confirm', "Confirm"),
        ('cancel', "Cancelled"),
        ],
        string="Status",
        readonly=True, copy=False, index=True,
        default='draft')
    
    def action_stage_draft(self):       
        self.state = 'draft'
    def action_stage_sent(self):
        self.state = 'sent'
    def action_stage_confirm(self):
        self.state = 'confirm'
    def action_stage_cancel(self):
        self.state = 'cancel'

    @api.onchange('college_id')
    def _onchange_get_values(self):
        if self.college_id:
            self.college_master_Lines = [(5, 0, 0)] 
            values = []
            for rec in self.college_id.student_master_Lines:
                vals = (0,0,{
                        'name': rec.subject.id,
                        'practicals': rec.practical,
                        'theories': rec.theory,
                        'totalmark': rec.total
                           })
                values.append(vals)
            self.college_master_Lines = values
            self.dateofbirth = self.college_id.dob
        else:
            self.college_master_Lines = [(5, 0, 0)] 


    college_master_Lines = fields.One2many('college.master.line','student_id',string="College Master Line")

class CollegeMasterLine(models.Model):
    _name = "college.master.line"
    _description = "College Master Line"

    # name = fields.Char(string="Subject")
    name = fields.Many2one('subject.master',string="Subject", required=True)
    practicals = fields.Integer(string="Practical")  
    theories = fields.Integer(string="Theory")
 

    totalmark = fields.Float(string="Total",compute="action_update_total")

    student_id = fields.Many2one('college.master', ondelete='cascade')
    

    @api.depends('practicals','theories')
    def action_update_total(self):
        for rec in self:
            rec.totalmark = rec.practicals + rec.theories





