# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import fields, models, _
from odoo.exceptions import UserError, AccessError

class SubjectMaster(models.Model):
    
    _name = "subject.master"
    _description = "Subject Master"
    _rec_name = 'subject'   



    subject = fields.Char(string="Subjects") 
    s_code = fields.Char(string="Subject Code" ) 
    
    
# class VehicleMasterLine(models.Model):
#     _name = "vehicle.master.line"
#     _description = "Vehicle Master Line"

#     name = fields.Char(string="Name")
#     product_id = fields.Many2one('product.product', string="Product")
#     partner_id = fields.Many2one('res.partner', string="Customer")
    
#     quantity = fields.Integer(string="Qty")
#     vehicle_id = fields.Many2one('vehicle.master')





    