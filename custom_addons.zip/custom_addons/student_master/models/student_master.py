# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import api,fields, models, _
from odoo.exceptions import UserError, AccessError,ValidationError
from datetime import datetime
from dateutil.relativedelta import relativedelta

class StudentMaster(models.Model):
    
    _name = "student.master"
    _description = "Student Master"


    name = fields.Char(string="Student Name", required=True, index=True, copy=False)
    roll_no = fields.Char('Roll Number')	
    dept = fields.Char('Department')
    s_class = fields.Char(string="Class")
    dob = fields.Date("Date of Birth")
    age = fields.Char("Age",compute="_compute_age",)
    grade = fields.Char("Grade")
    confirmed_by_id  = fields.Many2one('res.users',string="Confirmed by")
    confirmed_on =  fields.Datetime("Confirmed on")
    cancelled_by_id  = fields.Many2one('res.users',string="Cancelled by")
    cancelled_on =  fields.Datetime("Cancelled on")
    totalmark = fields.Float("Total", compute='total_mark')
    student_master_Lines = fields.One2many('student.master.line','stu_id',string="Student Master Line")
    state = fields.Selection([
        ('draft', "Draft"),
        ('sent', "Sent"),
        ('confirm', "Confirm"),
        ('cancel', "Cancelled"),
        ],
        string="Status",
        readonly=True, copy=False, index=True,
        default='draft')
    
    def action_stage_draft(self):       
        self.state = 'draft'
    def action_stage_sent(self):
        self.state = 'sent'

    def action_stage_confirm(self):         
        self.state = 'confirm'
        self.confirmed_by_id = self.env.user.id
        self.confirmed_on = datetime.now()

    def action_stage_cancel(self):
        self.state = 'cancel'
        self.cancelled_by_id = self.env.user.id
        self.cancelled_on = datetime.now()

    @api.depends('dob')
    def _compute_age(self):
        for record in self:
            if record.dob:
                today = datetime.today().date()
                dob = fields.Date.from_string(record.dob)
                delta = relativedelta(today, dob)
                
                # Constructing the age string: "X years, Y months, and Z days"
                age_str = ""
                
                if delta.years > 0:
                    age_str += f"{delta.years} Years"
                
                if delta.months > 0:
                    if age_str:
                        age_str += " "  # Adding a separator if years are already added
                    age_str += f"{delta.months} Months"
                
                if delta.days > 0:
                    if age_str:
                        age_str += " "  # Adding a separator if months are already added
                    age_str += f"{delta.days} Days"
                
                # If the computed age has no years or months, we still want to show the days
                if not age_str:  
                    age_str = f"{delta.days} Days"
                    
                record.age = age_str
            else:
                record.age = ''  # Clear the field if DOB is not provided

    def action_unlink(self):
        clg = self.env['college.master'].search([('college_id','=',self.id)])
        if clg:
            clg.unlink()
        else:
            raise ValidationError('No record found !')

    def action_update_values(self):
        clg = self.env['college.master'].search([('college_id','=',self.id)])
        if clg:
            clg.write({'section':self.s_class})


    def write(self, values):
        result = super(StudentMaster,self).write(values)
        clg = self.env['college.master'].search([('college_id','=',self.id)])
        if clg:
            clg.write({'section':self.s_class})
        return result 



    @api.depends('student_master_Lines.total')
    def total_mark(self):
        tot=0
        for rec in self.student_master_Lines:
            tot += rec.total
        self.totalmark = tot 

    def action_create_clg(self):
        clg = self.env['college.master'].search([('college_id','=',self.id)])
        if len(clg) == 0:
            line_vals = []
            for lines in self.student_master_Lines:
                vals = (0,0, {
                    'name':lines.subject.id,
                    'practicals':lines.practical,
                    'theories':lines.theory,
                    'totalmark':lines.total
                    })
                line_vals.append(vals)
            clg = self.env['college.master'].create({
                'name':self.name,
                'college_id':self.id,
                'roll_number':self.roll_no, 
                'department':self.dept,
                'section':self.s_class,
                'dateofbirth':self.dob,
                'college_master_Lines':line_vals

                })
           
        else:
            raise ValidationError('Record Exist')



   

    # @api.constrains('student_master_Lines')
    # def action_validate_lines(self):
    #     if not self.student_master_Lines:
    #         raise ValidationError(_("Kindly enter the value in the student master line."))

class StudentMasterLine(models.Model):
    _name = "student.master.line"
    _description = "Student Master Line"

    # name = fields.Char(string="Subject")
    subject = fields.Many2one('subject.master',string="Subject")
    practical = fields.Integer(string="Practical")  
    theory = fields.Integer(string="Theory")
    code = fields.Char("Code")
    total = fields.Float(string="Total",compute="action_update_total")
    stu_id = fields.Many2one('student.master',ondelete="cascade")
    



    @api.depends('practical','theory')
    def action_update_total(self):
        for rec in self:
            rec.total = rec.practical + rec.theory


    @api.onchange('subject')
    def _onchange_get_code(self):
        for rec in self:
            rec.code = rec.subject.s_code





