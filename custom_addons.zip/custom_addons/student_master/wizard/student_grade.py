# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import api,fields, models, _
from odoo.exceptions import UserError, AccessError


class StudentGrade(models.TransientModel):
    
    _name = "student.grade"
    _description = "Student Grade"

    name = fields.Char(string="Grade")
    student_id = fields.Many2one('student.master',string="Student ID")
    totalmark = fields.Float("Total", compute='_total_mark')

    student_mark_Lines = fields.One2many('student.mark','mark_id',string="Student Mark Line")

    @api.depends('student_mark_Lines.total')
    def _total_mark(self):
        tot=0
        for rec in self.student_mark_Lines:
            tot += rec.total
        self.totalmark = tot 

    def action_pass_mark(self):
        a = self.env.context.get('active_ids')
        student_master = self.env['student.master'].browse(self.env.context.get('active_ids'))
        line_vals = []
        for line in self.student_mark_Lines:
            vals = (0,0, {
                    'subject':line.subject.id,
                    'code':line.code,
                    'practical':line.practical,
                    'theory':line.theory,
                    'total':line.total,
                    'stu_id':student_master.id
                    })
            line_vals.append(vals)
        student_master.write({'student_master_Lines':line_vals})
        self.student_id.grade = self.name
           


class StudentMark(models.TransientModel):
    
    _name = "student.mark"
    _description = "Student Mark"

    name = fields.Char(string="Grade")
    # grade_id = fields.Many2one('student.master',string="Library")
    subject = fields.Many2one('subject.master',string="Subject", required=True)
    practical = fields.Integer(string="Practical")  
    theory = fields.Integer(string="Theory")
    code = fields.Char("Code")
    total = fields.Float(string="Total",compute="action_update_total")
   
    mark_id=fields.Many2one('student.grade')
    
    @api.depends('practical','theory')
    def action_update_total(self):
        for rec in self:
            rec.total = rec.practical + rec.theory


    @api.onchange('subject')
    def _onchange_get_code(self):
        for rec in self:
            rec.code = rec.subject.s_code

