# -*- coding: utf-8 -*-	
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Student',
    'version': '17.0',
    'category': 'Student',
    'sequence': -100,	
    'summary': 'Student',
    'description': "Student Master",
    "author": "PPTS [India] Pvt.Ltd.",
    "website": "http://www.pptssolutions.com",
    'depends': ['base'],
    'data': [
        'security/ir.model.access.csv',
        'wizard/student_grade_views.xml',
        'views/student_master_views.xml',
	    'views/subject_master.xml',
	    'views/college_master_views.xml',
    
    ],
    
    
    'installable': True,
    'auto_install': False,
    'application': True,
}
