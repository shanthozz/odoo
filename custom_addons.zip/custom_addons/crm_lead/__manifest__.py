# -*- coding: utf-8 -*-	
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Lead Mail',
    'version': '17.0',
    'category': 'Lead Mail',
    'sequence': -100,	
    'summary': 'Crm Lead Mail',
    'description': "Crm Lead Mail",
    'depends': ['base','crm','mail'],
    'data': [
        'security/ir.model.access.csv',
        'views/crm_lead_mail.xml',
        'views/lead_mail_template.xml',
        'views/crm_lead_views.xml',
        # 'views/lead_mail_schedule_action.xml',
    ],
    'licence' : 'LGPL-3',
    'installable': True,
    'auto_install': False,
    'application': True,
}
