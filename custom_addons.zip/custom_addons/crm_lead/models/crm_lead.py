from odoo import models, fields
from datetime import datetime, timedelta
from odoo.exceptions import ValidationError


class CrmLead(models.Model):
    _inherit = "crm.lead"
    
    def get_leads(self):
        pass
        # leads = self.env['crm.lead'].search([('activity_ids', '=', False)])
        # print(leads)
        # users = self.env['lead.mail'].search([('name', '=', 'CRM Lead Mail Group - A')])
        # for user in users:
        # # Prepare a list to collect leads without activities
        #     leads_without_activity = []
        
        # # Iterate through all leads
        #     for lead in leads:
        #         if not lead.activity_ids:
        #             current_time = datetime.now()
        #             for user_mail in user.mail_ids:
        #                 user_time_duration = int(user_mail.time_duration)
                        
        #                 # If the allocated time has passed, add the lead to the list
        #                 allocated_time = lead.create_date + timedelta(hours=user_time_duration)
        #                 if current_time >= allocated_time:
        #                     leads_without_activity.append(f'Lead ID: {lead.id} - Created on: {lead.create_date.strftime("%Y-%m-%d %H:%M:%S")}')
                            
        #                     # No need to send an email for each individual lead, instead collect all leads
        #                     break

        #                 # If the current user is the last in the sequence and the time has passed, add the lead
        #                 if user_mail == user.mail_ids[-1]:
        #                     leads_without_activity.append(f'Lead ID: {lead.id} - Created on: {lead.create_date.strftime("%Y-%m-%d %H:%M:%S")}')
            
        #     # If there are any leads without activities, send one email
        #     if leads_without_activity:
        #         lead_info = "<ul>" + "".join([f"<li>{lead}</li>" for lead in leads_without_activity]) + "</ul>"
                
        #         mail_values = {
        #             'subject': 'Leads with No Activity Assigned',
        #             'body_html': f'<p>The following leads do not have any activities assigned:</p>{lead_info}',
        #             'email_to': user_mail.name.email,  # Send it to the current user's email
        #         }
                
        #         # Create and send the email
        #         mail = self.env['mail.mail'].create(mail_values)
        #         mail.send()

        #         print(f'Email sent to {user_mail.name.email} regarding leads without activities.')

