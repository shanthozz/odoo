from odoo import models, api, fields
from odoo.exceptions import ValidationError

class LeadMail(models.Model):
    _name = "lead.mail"
    _description = "Crm Lead Mail"

    mail_ids = fields.One2many("lead.mail.users",'lead_mail',string='Mail Users')
    name = fields.Char(string="Groups")

    @api.model
    def create(self, vals):
        # Check if a record already exists in the model
        existing_record = self.search([], limit=1)
        if existing_record:
            raise ValidationError("You are Not Allowed to Create a Record !! , Instead of You Can add Users in a Existing Record itself")
        return super(LeadMail, self).create(vals)

class LeadMailUsers(models.Model):
    _name = "lead.mail.users"
    _description = "Lead Mail User"
    _order = "sequence"

    sequence = fields.Integer(default=10)
    lead_mail = fields.Many2one("lead.mail",string='Lead Mails')
    name = fields.Many2one("res.users",string="Users")
    time_duration = fields.Selection([
        ('1', "1 hour"),
        ('2', "2 hour"),
        ('4', "4 hour"),
        ('6', "6 hour"),
        ],      
        index=True ,string="Duration in hours")